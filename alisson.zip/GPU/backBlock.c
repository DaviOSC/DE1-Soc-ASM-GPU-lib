#include "graphic_processor.c"
#include <unistd.h>

int main() {
    createMappingMemory();
    
    int i, j, k;
    // for (k=0; k<524; k++){
        for(i=0; i<15; i++){
            for(j=0; j<20; j++){

                while(1){ if(isFull() == 0) { tetrisBlock(j, i, 0, 0, 0); break; } }
                while(1){ if(isFull() == 0) { tetrisBlock(j, i, 0, 0, 0); break; } }

                //primeiro bloco
                // tetrisBlock(, 14, 0, 0, 0); // bloco embaixo do primeiro bloco
            }
        }
    // }
    // while(1){ if(isFull() == 0) { tetrisBlock(14, 19, 0, 0, 0); break; }}
    // tetrisBlock(16, 13, 0, 0, 0); // bloco do lado do primiero block
    return 0;
}