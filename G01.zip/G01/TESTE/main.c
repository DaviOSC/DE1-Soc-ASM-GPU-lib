int main() {
    	createMappingMemory();
    	set_background_color(0b111, 0b111, 0b000);
		set_background_block(50, 50, 0,0,0);
		set_sprite(50, 1, 50, 1, 3);
        closeMappingMemory();
}