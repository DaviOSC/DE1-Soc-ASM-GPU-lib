#include "graphic_processor.h"
int main() {
    Sprite sprt_1;
    sprt_1.ativo = 1; sprt_1.data_register  = 1;  sprt_1.coord_x = 220;  sprt_1.coord_y = 100;  sprt_1.offset = 0;
    createMappingMemory();
    //set_background_color(0b000, 0b000, 0b111);
    set_background_color(0b000, 0b111, 0b000);
    //set_background_color(0b111, 0b000, 0b000);

    //while(1){ if(isFull() == 0) { set_sprite(sprt_1.data_register, sprt_1.coord_x, sprt_1.coord_y, sprt_1.offset, sprt_1.ativo); break; } }
    while(1)
    {
        if(isFull() == 0)
        { setPolygon(0b0000, 0b0011, 0b000111000, 1, 0b0001, 50, 50); break; } }

    closeMappingMemory();
}
