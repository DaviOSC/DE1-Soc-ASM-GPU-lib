//Barramentos da GPU
#define DATA_A 0X70
#define DATA_B 0X80
#define RESET_PULSECOUNTER 0X90
#define SCREEN 0XA0
#define WRFULL 0XB0
#define WRREG 0XC0

//Mapeamento de memória

#define ALT_LWFPGASLVS_OFST 0xff200000
#define HW_REGS_BASE 0xfc000000
#define HW_REGS_SPAN 0x04000000
