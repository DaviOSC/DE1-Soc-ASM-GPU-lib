# DE1-Soc-ASM-GPU-lib

# Trello: 
- https://trello.com/b/MT18QH97/sd

# GPT: 
- https://chatgpt.com/share/670ac12f-6718-8003-8857-b176f2d0ca2b
- https://chatgpt.com/share/670c39ec-804c-8003-942f-fa64f709721b
- https://chatgpt.com/share/670c3a0b-1edc-8003-b0ae-fc1e65823288