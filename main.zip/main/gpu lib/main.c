#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include "fpga_gpu.h"

int main()
{
    create_mapping_memory();
    send_instruction(0,0b111000000);
    // set_polygon(0, 0xfff, 0, 1, 100, 100);
    // set_sprite(1, 0, 1, 200, 200);
    // set_background_color(0, 7, 0);
    // set_background_block(10, 10, 7, 0, 0);

    usleep(2000000); // 2 seg

    send_instruction(0,0);
    // set_polygon(0, 0xfff, 0, 0, 100, 100);
    // set_sprite(1, 0, 0, 200, 200);
    // set_background_color(0, 0, 0);
    // set_background_block(10, 10, 0, 0, 0);
    close_mapping_memory();
    return 0;
}