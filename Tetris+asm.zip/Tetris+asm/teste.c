#include "graphic_processor.h"
#include <intelfpgaup/video.h>

int main() {
    create_mapping_memory();
    //video_open();
    set_background_color(5,5,1);

}